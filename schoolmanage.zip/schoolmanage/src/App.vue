<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<script>
  import global from './components/Global';
export default {
  name: 'app',
  created() {
    if(this.$route.fullPath!=='/TeacherPage') {
      let _this = this;
      fetch(global.baseUrl + '/scores/index/', {
        method: 'GET'
      }).then((res) => {
        console.log(res);
        if (res.status === 400) {
          _this.$router.push('/');
        }
      })
    }

  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 100%;
  height: 100%;
  /*background-color: darkblue;*/
}

html, body{
    width: 100%;
    height: 100%;
    margin: 0;
    padding: 0;
}



</style>
