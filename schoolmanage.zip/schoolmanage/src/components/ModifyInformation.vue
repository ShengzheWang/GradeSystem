<template>
    <div id="ConfirmAccount">
        <div class="top-bar">
            <div class="bar-icon">
                <span><i style="font-size: 30px;" class="el-icon-back" @click="linkBack"></i></span>
            </div>
        </div>

        <div class="main-content animated bounceInRight">
            <div class="fonts-panel">
                <span>修改密码</span>
            </div>
            <div class="form-panel">
                    <div class="input-panel">
                        <label>输入旧密码</label><br/>
                        <input type="password" v-model="old_password" class="confirm-input"/>
                    </div>

                    <div class="input-panel">
                        <label>设置新密码</label><br/>
                        <input type="password" v-model="password" class="confirm-input"/>
                    </div>
                    <div class="input-panel">
                        <label>确认新密码</label><br/>
                        <input type="password" v-model="confirmPassword" class="confirm-input"/>
                        <div style="margin-top: 10px;" v-show="showError">
                            <span style="color: red;font-size: 16px;margin-top: 10px;">两次输入密码不一致哦~</span>
                        </div>
                    </div>

                <mu-button color="primary" class="active" @click="linkTo" >确定修改</mu-button>
            </div>
        </div>

    </div>
</template>

<script>
    import global from './Global';
    export default {
        name: "ConfrimAccount",
        data(){
            return{
                id:'',
                password: '',
                old_password:'',
                confirmPassword: '',
                email:'',
                studentType:'普通文科',
                showPassword: false,
                showError: false,
            }
        },
        created(){
          this.$data.id = this.$route.query.id;
        },
        watch:{
            confirmPassword(oldV, newV){
                if(this.$data.password){
                    if(this.$data.password === this.$data.confirmPassword){
                        this.$data.showError = false;
                    }else{
                        this.$data.showError = true;
                    }
                }else{
                    this.$data.showError = false;
                }

            }
        },
        methods:{
            linkBack(){
                this.$router.push({path:'/StudentGrade',query:{id: this.$data.id}});
            },
            linkTo() {


                let _this = this;
                if(this.$data.confirmPassword === this.$data.password) {
                    fetch(global.baseUrl + '/scores/change_password/', {
                        method: 'post',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({
                            old_password: this.$data.old_password,
                            password: this.$data.password,
                            id: this.$data.id
                        }),
                    }).then((res) => res.json())
                        .then((response) => {
                            // console.log('response');
                            if (response.is_success === true) {
                                _this.$message({
                                    type: 'success',
                                    message: '激活成功'
                                })
                                _this.$router.push({path:'/StudentGrade',query:{id: _this.$data.id}});
                            } else {
                                _this.$message({
                                    type: 'error',
                                    message: '好像有点问题...'
                                })
                            }
                        }).catch((error) => {
                        _this.$message({
                            type: 'error',
                            message: '好像有点问题...'
                        })
                    });
                }else{
                    this.$data.showError = true;
                }
            }
        }
    }
</script>

<style scoped lang="less">
    #ConfirmAccount{
        padding: 1px;
        width: 100vw;
        height: 100vh;
        .active{
            width:100%;
            margin-top: 10vh;
            font-size: 17px;
        }
        .top-bar{
            width: 100vw;
            height: 12vw;
            text-align: left;

            .bar-icon{
                margin-left: 5vw;
                margin-top: 2vw;
                color: dodgerblue;
                font-weight: bold;
            }
        }
        .main-content {
            width: 80%;
            margin-left: auto;
            margin-right: auto;
            .fonts-panel {
                margin-top: 5vh;
                /*margin-left: auto;*/
                /*margin-right: auto;*/
                text-align: left;
                font-size: 30px;
                /*background-color: orange;*/
            }

            .form-panel {
                text-align: left;
                margin-top: 7vh;

                .confirm-input{
                    margin-top: 0.5vh;
                    outline: none;
                    border: none;
                    border-bottom: 0.1px solid gray;
                    width: 100%;
                    padding-bottom: 1.2vh;
                    font-size: 20px;
                    background-color: #fAfAfA;
                }

                .input-panel{
                    margin-top: 5vh;
                }
                .button-panel{
                    margin-top: 5vh;
                    width: 80%;
                    margin-right: auto;
                    margin-left: auto;

                    button{
                        width: 100%;
                        max-width: 200px;
                        height: 10vw;
                        max-height: 50px;
                        outline: none;
                        border: none;
                        background-color: dodgerblue;
                        color: white;
                        border-radius: 5px;
                        font-size: 16px;
                    }
                }
            }
        }
        @media screen and (min-width: 700px){
            .main-content{
                width: 60%;
            }
            .input-panel{
                /*width: 55%;*/
                text-align: left;
            }
            .button-panel{
                text-align: left;
                /*width: 50%;*/
                margin-left: 0;

            }

        }

    }
</style>
