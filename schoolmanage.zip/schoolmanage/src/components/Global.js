
let global={
    baseUrl:'http://121.192.167.34:8000',
    id:''
};


export default global;
