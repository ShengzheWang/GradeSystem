<template>
    <div class="TeacherPage" >

        <el-dialog :visible.sync="showStuModal" width="400" height="200" title="上传名单" v-loading="loading">
            <div>
                <el-form>
                    <el-form-item label="请上传相关文件:">
                        <input type="file" id="upload_stu" @change="successStuFile" />
                    </el-form-item>
                </el-form>
                <el-button type="primary" @click="submitStuList">确认上传</el-button>
            </div>
        </el-dialog>

        <el-dialog :visible.sync="showDownModal" width="400" height="200" title="导出成绩" >
            <div>
                <el-form>
                    <el-form-item label="请输入导出年级:">
                        <el-input v-model="grade"></el-input>
                    </el-form-item>
                </el-form>
                <el-button type="primary" @click="getGradeList">确认下载</el-button>
            </div>
        </el-dialog>

        <el-dialog :visible.sync="showGraModal" width="400" height="200" title="上传名单" v-loading="loading">
            <div>
                <el-form>
                    <el-form-item label="请选择上传科目">
                        <el-select v-model="upload_book">
                            <el-option label="计算机基础" value="Computer"></el-option>
                            <el-option label="高等数学" value="Math"></el-option>
                            <el-option label="大学语文" value="Chinese"></el-option>
                            <el-option label="英语" value="English"></el-option>
                            <el-option label="形势与政策" value="Political"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="请选择上传学期">
                        <el-select v-model="upload_sem">
                            <el-option label="第一学期" value="1"></el-option>
                            <el-option label="第二学期" value="2"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-form-item label="请上传相关文件:">
                        <input type="file" id="upload_gra" @change="successGradeFile" />
                    </el-form-item>
                </el-form>
                <el-button type="primary" @click="submitScoreList">确认上传</el-button>
            </div>
        </el-dialog>
        <div
            style="margin-top: 40px;width: 100%"
        >
            <div style="width: 33%;float: left;margin-left: 0.5%">
                <div @click="()=>{this.$data.showStuModal=true}">
                    <el-card
                        style="width: 80%;height:200px;margin-left: auto;margin-right: auto"
                    >
                        <div style="width: 50px;margin-left: auto;margin-right: auto;margin-top: 10px;">
                            <img src="../assets/加.png" style="width: 50px;height:50px;"/>
                        </div>
                        <div style="width: 100%;text-align: center;font-size: 28px;margin-top: 20px;">
                            <span>上传名单</span>
                        </div>

                    </el-card>
                </div>
            </div>
            <div style="width: 33%;float: left">
                <div @click="()=>{this.$data.showGraModal=true}">
                    <el-card
                        style="width: 80%;height:200px;margin-left: auto;margin-right: auto"
                        >
                        <div style="width: 50px;margin-left: auto;margin-right: auto;margin-top: 10px;">
                            <img src="../assets/上传.png" style="width: 50px;height:50px;"/>
                        </div>
                        <div style="width: 100%;text-align: center;font-size: 28px;margin-top: 20px;">
                            <span>上传成绩</span>
                        </div>

                    </el-card>
                </div>
            </div>
            <div style="width: 33%;float: left">
                <div @click="()=>{this.$data.showDownModal}">
                    <div @click="()=>{
                            this.$data.showDownModal = true;
                            // this.$router.push('/TeacherPage');
                    }">
                        <el-card
                                style="width: 80%;height:200px;margin-left: auto;margin-right: auto"
                        >
                            <div style="width: 50px;margin-left: auto;margin-right: auto;margin-top: 10px;">
                                <img src="../assets/下载.png" style="width: 50px;height:50px;"/>
                            </div>
                            <div style="width: 100%;text-align: center;font-size: 28px;margin-top: 20px;">
                                <span>导出成绩</span>
                            </div>

                        </el-card>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
    import global from './Global';
    export default {
        name: "TeacherPage",
        data(){
            return{
                loading: false,
                grade:'',
                showStuModal: false,
                upload_stu_file: '',
                upload_gra_file:'',
                showGraModal:false,
                showDownModal: false,
                upload_sem: '1',
                upload_book:'Computer'
            }

        },
        created(){
            console.log(document.referrer);

            if(document.referrer!=='http://121.192.167.34/admin/*'){
                this.$router.push('/');
            }

        },
        methods:{
            successStuFile(){
                this.$data.upload_stu_file = document.getElementById('upload_stu').files[0];
            },
            successGradeFile(){
                this.$data.upload_gra_file = document.getElementById('upload_gra').files[0];

            },
            submitStuList() {
                let _this = this;
                if (!this.$data.upload_stu_file) {
                    this.$message({
                        type:'error',
                        message:'没有上传文件哦~'
                    })
                } else {
                    let formData1 = new FormData();
                    // console.log(this.$data.upload_stu_file.get('students'));
                    this.$data.loading = true;
                    // formData1.append('headers',{
                    //     enctype:'multipart/form-data'
                    // });
                    formData1.append('students', this.$data.upload_stu_file);
                    console.log(formData1.get('students'));



                    fetch(global.baseUrl + '/scores/add_students/', {
                        mode:'cors',
                        method: 'POST',
                        body: formData1
                    }).then((res) => res.json())
                        .then((response) => {
                            if(response.is_success===true) {
                                _this.$message({
                                    type:'success',
                                    message:'上传成功'
                                });

                            }else{
                                _this.$message({
                                    type:'error',
                                    message:'上传失败'
                                });
                            }

                            _this.$data.loading = false;
                        }).catch((error)=>{
                        _this.$message({
                            type:'error',
                            message:'上传失败'
                        });
                        _this.$data.loading = false;
                    })
                }
            },
            submitScoreList(){
                let formdata = new FormData();
                let _this = this;
                formdata.append('scores', this.$data.upload_gra_file);
                formdata.append('is_first_term', this.$data.upload_sem==='1' ? 1 : 0);
                formdata.append('subject',this.$data.upload_book);
                this.$data.loading = true;

                fetch(global.baseUrl+'/scores/add_scores/',{
                    method:'POST',
                    body: formdata
                }).then((res)=>res.json())
                    .then((response)=>{
                        if(response.is_success===true) {
                            _this.$message({
                                type:'success',
                                message:'上传成功'
                            });

                        }else{
                            _this.$message({
                                type:'error',
                                message:'上传失败'
                            });
                        }

                        _this.$data.loading = false;
                    }).catch((error)=>{
                    _this.$message({
                        type:'error',
                        message:'上传失败'
                    });
                    _this.$data.loading = false;
                })

            },
            getGradeList(){
                let a = document.createElement('a');
                let url = global.baseUrl+'/scores/download/'+this.$data.grade;
                let filename = this.$data.grade+'成绩.xlsx';
                a.href = url;
                a.download = filename;
                a.click();
                URL.revokeObjectURL(url);
                this.$message({
                    type:'success',
                    message:'正在下载中~'
                })
            }


        }
    }
</script>

<style>
    .TeacherPage{
        width: 100%;
        height:100%;

    }

</style>
