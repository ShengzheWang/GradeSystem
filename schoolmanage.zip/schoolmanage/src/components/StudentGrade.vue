<template>
    <div id="StudentGrade">
        <!--<div style="width: 100%;height:100%;background-color: rgba(0,0,0,0.6);">-->
        <el-card class="main-card" :body-style="{padding:'0'}">
            <div class="main-card-content">
                <div class="left-card">
                    <div class="name-bar">
                        {{myName}}
                    </div>
                    <div class="name-bar-2">
                        {{myStuNum}}
                    </div>
                    <div class="name-bar-3" @click="()=>{
                                                        this.$router.push({path:'/ModifyInformation', query:{id: this.$data.id}})}">
                        修改密码
                    </div>
                </div>
                <div class="right-card">
                    <div class="first-circle">
                        {{disType}}
                    </div>
                    <div class="second-circle">
                        {{readType}}
                    </div>
                </div>
            </div>
        </el-card>
        <el-card class="rank-card">
            <div v-if="hasGrade">
                <span style="font-size: 20px;">第 </span>
                <span style="font-size: 39px;font-weight: bold">{{rank}}</span>
                <span style="font-size: 20px;"> 名</span>
            </div>
            <div v-else>
                <span style="font-size: 22px;">目前暂无成绩排名哦~</span>
            </div>
        </el-card>
        <!--</div>-->
    </div>
</template>

<script>
    import global from './Global';
    export default {
        name: "ResetPassword",
        data(){
            return {
                id:'',
                disType:'新疆',
                readType:'文科',
                myName:'',
                myStuNum:'',
                rank:'2',
                hasGrade:false,
            }
        },
        created(){
            let _this = this;
            this.$data.id = this.$route.query.id;
          fetch(global.baseUrl+'/scores/student/'+this.$data.id).then(res=>res.json()).then((response)=>{
              console.log(response);
              _this.$data.disType = response.isSinkang === true ? '新疆' : '普通';
              _this.$data.readType = response.is_art === true ? '文科' : '理科';
              _this.$data.hasGrade = response.show_grade;
              _this.$data.myStuNum = response.student_number;
              _this.$data.myName = response.name;
              _this.$data.rank = response.rank
          })
        },
        methods:{

        }
    }
</script>

<style lang="less">
    #StudentGrade{
        width: 100%;
        height: 100%;
        /*background-image: url('../assets/back.jpg');*/
        background-size: cover;
        background-position: center;
        background-color: #fAfAfA;
        padding: 1px;
    }

    .main-card {
        margin-top: 40px;
        width: 90%;
        height: 100px;
        margin-left: auto;
        margin-right: auto;
        background-color: white;
        padding: 8px;

    }


    .rank-card{
        margin-top: 10px;
        width: 90%;
        height: 90px;
        margin-left: auto;
        margin-right: auto;
        background-color: lightskyblue;
        color: #fff;
        text-align: center;
    }

    .left-card{
        width: 65%;
        padding-left: 5vw;

    }
    .right-card{
        width: 35%;
        text-align: center;

    }


    .main-card-content{
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: row;
    }


    .first-circle{
        margin-left: 1vw;
        width: 12.6vw;
        max-width: 50px;
        height: 12.6vw;
        max-height: 50px;
        background-color: orange;
        border-radius: 50%;
        float: left;
        line-height: 12.6vw;
        text-align: center;
        font-size: 14px;
        color: #fff;
        font-weight: bold;

    }

    .second-circle{
        float: left;
        margin-left: 1vw;
        width: 12.6vw;
        max-width: 50px;
        height: 12.6vw;
        max-height: 50px;
        background-color: dodgerblue;
        border-radius: 50%;
        line-height: 12.6vw;
        text-align: center;
        font-size: 14px;
        color: #fff;
        font-weight: bold;
    }

    @media screen and (min-width: 700px){
        .first-circle, .second-circle{
            line-height: 50px;
        }
    }




    .name-bar{
        font-size: 18px;
        font-weight: bold;
        /*text-align: center;*/
    }

    .name-bar-2{
        font-size: 14px;
        font-weight: bold;
        /*text-align: center;*/
    }

    .name-bar-3{
        font-size: 14px;
        font-weight: bold;
        /*text-align: center;*/
        color: dodgerblue;
    }




</style>
